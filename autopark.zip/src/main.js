import './style.css'

class BreakdownError extends Error {
  constructor(message) {
    super(message)
    this.name = 'BreakdownError'
  }
}

class Vehicle {
  static count = 0
  #isBroken = false

  constructor(brand) {
    this.brand = brand
    Vehicle.count += 1
  }

  getInfo() {
    return this.brand
  }

  drive() {
    if (this.#isBroken) {
      throw new BreakdownError('Нельзя ехать, транспорт сломан')
    }

    return 'Транспорт поехал'
  }

  breakVehicle() {
    this.#isBroken = true
  }

  repair() {
    this.#isBroken = false
  }

  getStatus() {
    if (this.#isBroken) {
      return 'Сломан'
    }

    return 'Работает'
  }

  static getCount() {
    return Vehicle.count
  }
}

class Car extends Vehicle {
  getInfo() {
    return `Машина ${this.brand}`
  }
}

class FastCar extends Car {}

class Truck extends Vehicle {
  getInfo() {
    return `Грузовик ${this.brand}`
  }
}

class Motorcycle extends Vehicle {
  getInfo() {
    return `Мотоцикл ${this.brand}`
  }
}

class Garage {
  #vehicles = []

  addVehicle(vehicle) {
    this.#vehicles.push(vehicle)
  }

  removeVehicle(index) {
    this.#vehicles.splice(index, 1)
  }

  getVehicles() {
    return this.#vehicles
  }
}

const garage = new Garage()
const cars = ['БМВ М4', 'Ауди А3', 'Лада Веста', 'Шкода Октавиа']
const motorcycles = ['Ямаха', 'Хонда']
const trucks = ['Камаз', 'Белаз']
let carIndex = 0
let motorcycleIndex = 0
let truckIndex = 0

for (let car of cars) {
  addCarToGarage(car)
}

for (let motorcycle of motorcycles) {
  garage.addVehicle(new Motorcycle(motorcycle))
}

for (let truck of trucks) {
  garage.addVehicle(new Truck(truck))
}

document.querySelector('#app').innerHTML = `
  <div>
    <h1>Гараж</h1>

    <button id="addCar">Добавить машину</button>
    <button id="addMotorcycle">Добавить мотоцикл</button>
    <button id="addTruck">Добавить грузовик</button>

    <p id="message"></p>
    <p id="count"></p>
    <div id="garage"></div>
  </div>
`

function showMessage(text) {
  document.querySelector('#message').textContent = text
}

function renderGarage() {
  const vehicles = garage.getVehicles()

  document.querySelector('#count').textContent = `Всего создано: ${Vehicle.getCount()}`

  document.querySelector('#garage').innerHTML = vehicles
    .map(
      (vehicle, index) => `
        <div class="vehicle">
          ${vehicle.getInfo()} | ${vehicle.getStatus()}
          <br>
          <button onclick="driveVehicle(${index})">ехать</button>
          <button onclick="breakVehicle(${index})">сломать</button>
          <button onclick="repairVehicle(${index})">чинить</button>
          <button onclick="removeVehicle(${index})">удалить</button>
        </div>
      `,
    )
    .join('')
}

window.driveVehicle = function (index) {
  try {
    const text = garage.getVehicles()[index].drive()
    showMessage(text)
  } catch (error) {
    showMessage(error.message)
  }
}

window.breakVehicle = function (index) {
  garage.getVehicles()[index].breakVehicle()
  showMessage('Транспорт сломался')
  renderGarage()
}

window.repairVehicle = function (index) {
  garage.getVehicles()[index].repair()
  showMessage('Транспорт починили')
  renderGarage()
}

window.removeVehicle = function (index) {
  garage.removeVehicle(index)
  showMessage('Транспорт удален из гаража')
  renderGarage()
}

function addCarToGarage(name) {
  if (name === 'БМВ М4') {
    garage.addVehicle(new FastCar(name))
  } else {
    garage.addVehicle(new Car(name))
  }
}

document.querySelector('#addCar').onclick = function () {
  const name = cars[carIndex]
  addCarToGarage(name)
  carIndex += 1

  if (carIndex === cars.length) {
    carIndex = 0
  }

  showMessage('Машина добавлена')
  renderGarage()
}

document.querySelector('#addTruck').onclick = function () {
  const name = trucks[truckIndex]
  garage.addVehicle(new Truck(name))
  truckIndex += 1

  if (truckIndex === trucks.length) {
    truckIndex = 0
  }

  showMessage('Грузовик добавлен')
  renderGarage()
}

document.querySelector('#addMotorcycle').onclick = function () {
  const name = motorcycles[motorcycleIndex]
  garage.addVehicle(new Motorcycle(name))
  motorcycleIndex += 1

  if (motorcycleIndex === motorcycles.length) {
    motorcycleIndex = 0
  }

  showMessage('Мотоцикл добавлен')
  renderGarage()
}

renderGarage()
